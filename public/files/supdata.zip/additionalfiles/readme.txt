Additional Files
The following data files are available for the paper:

"Selection for resistance to oseltamivir in seasonal and pandemic H1N1 influenza and widespread co-circulation of the two lineages"

Daniel A. Janies *, Igor O. Voronkin, Jonathon Studer, Jori Hardman, Boyan B. Alexandrov, Travis W. Treseder, and Chandni Valson

Department of Biomedical Informatics, The Ohio State University, College of Medicine, Columbus, OH 43210 USA

* Corresponding author 
Email Addresses: Daniel.Janies@osumc.edu

Additional Files

Additional file 1
Title: Character optimization of H275Y on a tree based on NA segments from the pandemic H1N1 lineage. 
Description: This file is in scalable portable document format. The mutation H275Y visualized in color (green=H=susceptible to oseltamivir : red=Y=resistant to oseltamivir) on the best tree. 

Additional file 2
Title: Accession numbers of the neuraminidase nucleotide sequences used in the phylogenetic and geographic study of pandemic H1N1 influenza A.
Description: GISAID sequences are available at http://www.gisaid.org
GenBank sequences are available at http://ncbi.nlm.nih.gov.

Additional file 3
Title: Character optimization of H275Y on a tree based on NA segments from the seasonal H1N1 lineage. 
Description: This file is in scalable portable document format. The mutation H275Y visualized in color (green=H=susceptible to oseltamivir : red=Y=resistant to oseltamivir) on the best tree. 

Additional file 4
Title: Accession numbers of the neuraminidase nucleotide sequences used in the phylogenetic and geographic study of seasonal H1N1 influenza A.
Description: GISAID sequences are available at http://www.gisaid.org
GenBank sequences are available at http://ncbi.nlm.nih.gov.

Additional file 5
Title:  Heuristic maximum likelihood tree based on NA segments from the pandemic H1N1 lineage. 
Description: The file is in nexus format.

Additional file 6
Title:  Heuristic maximum likelihood tree based on NA segments from the seasonal H1N1 lineage. 
Description: The file is in nexus format.

Additional file 7
Title:  An interactive visualization of populations of zanamivir-resistant seasonal H1N1. 
Description: A KML file suitable for viewing with Google Earth � (http://earth.google.com) or other virtual globe software.  Once the user opens the file in Google Earth, the user will see white points that represent isolates of seasonal H1N1 that are resistant to zanamivir.

Additional file 8
Title:  An interactive visualization of populations of oseltamivir-resistant seasonal H1N1 influenza and pandemic influenza in co-circulation across the globe. 
Description: A KML file suitable for viewing with Google Earth � (http://earth.google.com) or other virtual globe software.  Once the user opens the KML file in Google Earth, the user will see red points that represent isolates of seasonal H1N1 that are resistant to oseltamivir.  Green points represent isolates of pandemic H1N1 that are susceptible to oseltamivir.  Yellow points represent isolates of pandemic H1N1 that are resistant to oseltamivir.  Clicking on a point will reveal if various isolates co-circulate in that region.

Additional file 9 
Title: Acknowledgements
Description: Acknowledgements for researchers and institutions who submitted sequence data to GISAID and GenBank.